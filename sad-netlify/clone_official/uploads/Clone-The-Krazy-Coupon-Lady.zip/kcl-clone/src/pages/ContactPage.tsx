import type React from 'react';

const ContactPage: React.FC = () => (
  <div className="max-w-7xl mx-auto p-6">
    <h1 className="text-3xl font-uniforma mb-4">Contact Us</h1>
    {/* TODO: Clone contact page content */}
  </div>
);

export default ContactPage;
