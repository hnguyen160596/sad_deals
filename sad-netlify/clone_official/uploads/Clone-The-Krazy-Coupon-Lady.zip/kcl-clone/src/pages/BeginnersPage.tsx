import type React from 'react';

const BeginnersPage: React.FC = () => (
  <div className="max-w-7xl mx-auto p-6">
    <h1 className="text-3xl font-uniforma mb-4">How to Coupon (Beginners)</h1>
    {/* TODO: Clone Beginner's guide content here */}
  </div>
);

export default BeginnersPage;
