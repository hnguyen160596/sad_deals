import type React from 'react';

const TipsListPage: React.FC = () => (
  <div className="max-w-7xl mx-auto p-6">
    <h1 className="text-3xl font-uniforma mb-4">Savings Hacks</h1>
    {/* TODO: Clone the list of savings hacks here */}
  </div>
);

export default TipsListPage;
