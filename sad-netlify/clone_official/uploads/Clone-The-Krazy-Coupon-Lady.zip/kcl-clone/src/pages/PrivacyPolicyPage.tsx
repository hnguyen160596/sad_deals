import type React from 'react';

const PrivacyPolicyPage: React.FC = () => (
  <div className="max-w-7xl mx-auto p-6">
    <h1 className="text-3xl font-uniforma mb-4">Privacy Policy</h1>
    {/* TODO: Clone full privacy policy content here */}
  </div>
);

export default PrivacyPolicyPage;
