import Layout from './components/Layout';
import { Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import StorePage from './pages/StorePage';
import CouponCategoryPage from './pages/CouponCategoryPage';
import DealCategoryPage from './pages/DealCategoryPage';
import TodaysDealsPage from './pages/TodaysDealsPage';
import TipsListPage from './pages/TipsListPage';
import TipDetailPage from './pages/TipDetailPage';
import AllStoresPage from './pages/AllStoresPage';
import PrivacyPolicyPage from './pages/PrivacyPolicyPage';
import ContactPage from './pages/ContactPage';
import BeginnersPage from './pages/BeginnersPage';
import PostPage from './pages/PostPage';
import NotFoundPage from './pages/NotFoundPage';
import AdminLogin from './pages/AdminLogin';
import AdminDashboard from './pages/AdminDashboard';

function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/coupons-for/:store" element={<StorePage />} />
        <Route path="/coupons/:couponSlug" element={<CouponCategoryPage />} />
        <Route path="/deals" element={<TodaysDealsPage />} />
        <Route path="/deals/:dealSlug" element={<DealCategoryPage />} />
        <Route path="/tips" element={<TipsListPage />} />
        <Route path="/tips/:tipSlug" element={<TipDetailPage />} />
        <Route path="/stores" element={<AllStoresPage />} />
        <Route path="/krazy-coupon-lady-privacy-policy" element={<PrivacyPolicyPage />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/beginners" element={<BeginnersPage />} />
        <Route path="/admin-login" element={<AdminLogin />} />
        <Route path="/admin" element={<AdminDashboard />} />
        <Route path="/:year/:month/:day/:slug" element={<PostPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </Layout>
  );
}

export default App;
