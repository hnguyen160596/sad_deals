import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App.tsx";
import { BrowserRouter } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { CMSProvider } from './context/CMSContext';
import { DealsProvider } from './context/DealsContext';

const rootElement = document.getElementById("root");
if (!rootElement) {
  throw new Error("Failed to find root element");
}

createRoot(rootElement).render(
  <BrowserRouter>
    <AuthProvider>
      <DealsProvider>
        <CMSProvider>
          <App />
        </CMSProvider>
      </DealsProvider>
    </AuthProvider>
  </BrowserRouter>
);
